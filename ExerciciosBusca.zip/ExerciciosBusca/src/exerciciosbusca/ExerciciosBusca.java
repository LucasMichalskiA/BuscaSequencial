/*Lucas Michalski de Almeida RA:00217365*/
package exerciciosbusca;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class ExerciciosBusca {

    public static void main(String[] args) {
        int opcao = 0;
        Scanner x = new Scanner(System.in);
        System.out.println("Qual exercicio deseja executar? ");
        opcao = x.nextInt();

        switch (opcao) {
            case 1:
                exercicio1();
            case 2:
                exercicio2();
            case 3:
                exercicio3();
            case 4:
                exercicio4();
        }

    }

    private static void exercicio1() {
        int[] x = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
        int y = 0;

        Scanner number = new Scanner(System.in);
        System.out.println("Digite um numero de 0 a 20 que deseja encontrar: ");
        y = number.nextInt();

        System.out.println("Resultado: " + buscaSequencia(x, y) + "\n");

    }

    private static void exercicio2() {
        int[] x = new int[2000];
        int[] x1 = new int[2000];
        int[] x2 = new int[x1.length];
        int y;
        int retornoNord, retornoOrd;

        Random gerar = new Random();

        for (int i = 0; i < x.length; i++) {
            x[i] = gerar.nextInt(2001);
            x1[i] = x[i];
        }

        Scanner number = new Scanner(System.in);
        System.out.println("Digite um numero de 0 a 20 que deseja encontrar: ");
        y = number.nextInt();

        retornoNord = buscaSequencia(x, y);

        quickSort(x1, 0, x.length - 1);

        retornoOrd = BuscaSequenciaOrd(x1, y);

        if (retornoNord == -1 && retornoOrd == -1) {
            System.out.println("Não foi encontrado");
        }

        if (retornoNord < retornoOrd) {
            System.out.println("[VETOR NÃO ORDENADO]: " + Arrays.toString(x));
            System.out.println("Resultado sem ordenação: " + buscaSequencia(x, y) + "\n");
            System.out.println("[VETOR ORDENADO]: " + Arrays.toString(x1));
            System.out.println("Resultado sem ordenação: " + BuscaSequenciaOrd(x1, y) + "\n");
            System.out.println("Neste caso o metodo sem ordenação é mais vantajoso");
        } else {
            System.out.println("[VETOR NÃO ORDENADO]: " + Arrays.toString(x));
            System.out.println("Resultado sem ordenação: " + buscaSequencia(x, y) + "\n");
            System.out.println("[VETOR ORDENADO]: " + Arrays.toString(x1));
            System.out.println("Resultado com ordenação: " + BuscaSequenciaOrd(x1, y) + "\n");
            System.out.println("Neste caso o metodo com ordenação é mais vantajoso");
        }
    }

    private static void exercicio3() {
        int apostaMegaSena[] = new int[6];
        int resultadoMegaSena[] = {10, 15, 17, 20, 21, 35};
        int acertos = 0;

        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < apostaMegaSena.length; i++) {
            System.out.println("Informe o " + (i + 1) + "° número apostado: ");
            apostaMegaSena[i] = scanner.nextInt();
            if (BuscaSequencialOrd(resultadoMegaSena, apostaMegaSena[i]) == true) {
                acertos += 1;
            }
        }

        System.out.println("NÚMEROS APOSTADOS: " + Arrays.toString(apostaMegaSena) + "\n"
                + "RESULTADO: " + Arrays.toString(resultadoMegaSena) + "\n"
                + "Houve um total de acertos de : " + acertos);
        switch (acertos) {
            case 4:
                System.out.println("Com esse total de acertos, lhe rendeu um premio de: R$ 1.030,16 Juntamente com mais 4.757 ganhadores. Parabens!");
                break;
            case 5:
                System.out.println("Com esse total de acertos, lhe rendeu um premio de: R$ 46.356,22 Juntamente com mais 74 ganhadores. Parabens!");
                break;
            case 6:
                System.out.println(" Com esse total de acertos, lhe rendeu um premio de: R$ 35.000.000,00 Voce ganhou sozinho. Parabens!");
                break;
            default:
                System.out.println("HNão foi dessa vez, fica para próxima. Obrigado pela tentativa!");
                break;
        }
    }

    private static void exercicio4() {
        int[] ra = {1, 2, 3, 4, 5, 6, 7, 8, 10};
        String[] nome = {"Lucas Michalski ", "Tailon Prado", "Kedssy Luan", "Leonardo Almeida", "Matheus Lima", "Kleber Oliveira", "Paulo Sampaio", "Cesar Pedro", "Breno Caio"};
        int escolha, retorno;

        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < ra.length; i++) {
            System.out.println("Informe o aluno que voce deseja encontrar:  ");
            escolha = scanner.nextInt();

            retorno = BuscaSequenciaOrd(ra, escolha);

            System.out.println("O nome do aluno na posição " + retorno + " e seu nome é : " + nome[retorno]);

        }
    }

    private static int buscaSequencia(int[] x, int y) {
        int retorno = -1;

        for (int i = 0; i < x.length; i++) {
            if (x[i] == y) {
                retorno = i;
                break;
            }
        }
        return retorno;
    }

    private static int BuscaSequenciaOrd(int[] x, int y) {
        int retorno = -1;
        for (int i = 0; i < x.length && y >= x[i]; i++) {
            if (x[i] == y) {
                retorno = i;
                break;
            }
        }
        return retorno;
    }

    private static boolean BuscaSequencialOrd(int[] x, int y) {
        boolean retorno = false;
        for (int i = 0; i < x.length && y >= x[i]; i++) {
            if (x[i] == y) {
                retorno = true;
                break;
            }
        }
        return retorno;
    }

    private static void mergeSort(int[] v, int[] w, int ini, int fim) {
        if (ini < fim) {
            int meio = (ini + fim) / 2;
            mergeSort(v, w, ini, meio);
            mergeSort(v, w, meio + 1, fim);
            intercalar(v, w, ini, meio, fim);
        }
    }

    private static void intercalar(int[] v, int[] w, int ini, int meio, int fim) {
        for (int k = ini; k <= fim; k++) {
            w[k] = v[k];
        }

        int i = ini;
        int j = meio + 1;

        for (int k = ini; k <= fim; k++) {
            if (i > meio) {
                v[k] = w[j++];
            } else if (j > fim) {
                v[k] = w[i++];
            } else if (w[i] < w[j]) {
                v[k] = w[i++];
            } else {
                v[k] = w[j++];
            }
        }
    }

    private static void quickSort(int[] x, int inicio, int fim) {
        int posicao_pivo;

        if (inicio < fim) {
            posicao_pivo = particao(x, inicio, fim);
            quickSort(x, inicio, posicao_pivo - 1);
            quickSort(x, posicao_pivo + 1, fim);
        }
    }

    private static int particao(int[] x, int inicio, int fim) {
        int pivo, i, j;

        pivo = x[inicio];
        i = inicio + 1;
        j = fim;
        while (i <= j) {
            if (x[i] <= pivo) {
                i++;
            } else if (pivo < x[j]) {
                j--;
            } else {
                troca(x, i, j);
                i++;
                j--;
            }
        }
        x[inicio] = x[j];
        x[j] = pivo;
        return j;
    }

    private static void troca(int[] x, int i, int j) {
        int aux;
        aux = x[i];
        x[i] = x[j];
        x[j] = aux;
    }
}
